var x = 500;
var y = 300;
var xspeed = 10;
var yspeed = 15;

var r = 50;

function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(0,500,0,100);
  fill([255,0,0])
  ellipse(x, y, r*7, r*3);
  x -= xspeed;
  y -= yspeed;
  
  
  if (x > width - r || x < r) {
    xspeed = -xspeed;
  }
  if (y > height - r || y < r) {
    yspeed = -yspeed;
  }
  
}